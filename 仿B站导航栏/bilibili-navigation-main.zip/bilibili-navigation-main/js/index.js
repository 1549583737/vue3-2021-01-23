
let mapList = [{
    id: 'guochuang',
    text: '国创',
    top: 0,
    active: false
}, {
    id: 'yinyue',
    text: '音乐',
    top: 0,
    active: false
}, {
    id: 'fanju',
    text: '番剧',
    top: 0,
    active: false
}, {
    id: 'manhua',
    text: '漫画',
    top: 0,
    active: false
}, {
    id: 'wudao',
    text: '舞蹈',
    top: 0,
    active: false
}, {
    id: 'donghua',
    text: '动画',
    top: 0,
    active: false
}, {
    id: 'zixun',
    text: '资讯',
    top: 0,
    active: false
}];